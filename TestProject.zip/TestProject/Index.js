//          ACC - MOGA6 TSAR
//      puuid - WNqXWV_wD-1GkAfaxSkCbWW5ItB8UXgfCaWsVots0eEPCf7wqS60fM60fAasSO4zfb9Foi0XAPU2Cg
//      summonerID - 66uMAA-K-mfNx99tKcWyR-3P0mFdCB0Whq24IpBw95o1N14
//      accountID - KBWbUr2neWaDosVgA6p47FMAzsTcvRT-MQIqMTUwJKEcb2o
const profileName = document.getElementsByClassName("card-title")[0];
const flexRank = document.getElementById("flqRank");
const soloRank = document.getElementById("sqRank");
const soloLP = document.getElementById("sqLP");
const flexLP = document.getElementById("flqLP");
const secondTitle = document.getElementById("secondTitle");
const firstTitle = document.getElementById("firstTitle");

const profileNameS = document.getElementById("nameHolderS");
const flexRankS = document.getElementById("flqRankS");
const soloRankS = document.getElementById("sqRankS");
const soloLPS = document.getElementById("sqLPS");
const flexLPS = document.getElementById("flqLPS");
const secondTitleS = document.getElementById("secondTitleS");
const firstTitleS = document.getElementById("firstTitleS");


// const xhr = new XMLHttpRequest();
//
// xhr.open("GET","https://europe.api.riotgames.com/riot/account/v1/accounts/by-riot-id/MOGA6%20TSAR/TSAR?api_key=RGAPI-8c93ed88-3c9f-403c-ac15-50e7778705b4")
//
// xhr.onreadystatechange = function () {
//     if (xhr.readyState == 4 && xhr.status == 200) {
//         const response = JSON.parse(xhr.responseText);
//         console.log(response.status);
//     }
// }
// xhr.send();
//  info за акаунта име, таг, puuid
fetch(`https://europe.api.riotgames.com/riot/account/v1/accounts/by-riot-id/MOGA6%20TSAR/TSAR?api_key=RGAPI-c9b4a69c-93ff-4591-87cc-dde44a585c44`)
    .then((res) => res.json())
    .then ((data) => {
        console.log(data);
        profileName.innerHTML = data.gameName;
    })
    .catch((err) => console.log(err));
// Stelko
fetch(`https://europe.api.riotgames.com/riot/account/v1/accounts/by-puuid/IAzrrG-MK7iraOnkwf95JfgCSuYaMb4Qy5GOumBXtDa0qisPigXChlJ9WzLeGsyBwcpyvDqH2aKdDA?api_key=RGAPI-c9b4a69c-93ff-4591-87cc-dde44a585c44`)
    .then((res) => res.json())
    .then ((data) => {
        console.log(data);
        profileNameS.innerHTML = data.gameName;
    })
    .catch((err) => console.log(err));

//  ранковете на флекс и соло
fetch(`https://eun1.api.riotgames.com/lol/league/v4/entries/by-puuid/WNqXWV_wD-1GkAfaxSkCbWW5ItB8UXgfCaWsVots0eEPCf7wqS60fM60fAasSO4zfb9Foi0XAPU2Cg?api_key=RGAPI-c9b4a69c-93ff-4591-87cc-dde44a585c44`)
    .then((res) => res.json())
    .then((data) => {console.log(data);
    getRankMe(data);})
    .catch((err) => console.log(err));

// Stelko
fetch(`https://eun1.api.riotgames.com/lol/league/v4/entries/by-puuid/IAzrrG-MK7iraOnkwf95JfgCSuYaMb4Qy5GOumBXtDa0qisPigXChlJ9WzLeGsyBwcpyvDqH2aKdDA?api_key=RGAPI-c9b4a69c-93ff-4591-87cc-dde44a585c44`)
    .then((res) => res.json())
    .then((data) => {console.log(data);
        getRankStelko(data);})
    .catch((err) => console.log(err));


// fetch(`https://eun1.api.riotgames.com/lol/summoner/v4/summoners/66uMAA-K-mfNx99tKcWyR-3P0mFdCB0Whq24IpBw95o1N14?api_key=RGAPI-c9b4a69c-93ff-4591-87cc-dde44a585c44`)
//     .then((res) => res.json())
//     .then((data) => console.log(data))
//     .catch((err) => console.log(err));

//  Втори начин да достъпя
//const nameHolder = document.getElementById("nameHolder");
//nameHolder.innerHTML = "Hello";

function getRankMe(data){
    if(data[0].leagueId === "f32b0319-91a7-475f-9585-2737babc9b05"){
        soloRank.innerHTML += data[0].tier + " " + data[0].rank;
        soloLP.innerHTML += data[0].leaguePoints;
        flexRank.innerHTML += data[1].tier + " " + data[1].rank;
        flexLP.innerHTML += data[1].leaguePoints;
    }
    else{
        soloRank.innerHTML += data[1].tier + " " + data[1].rank;
        soloLP.innerHTML += data[1].leaguePoints;
        flexRank.innerHTML += data[0].tier + " " + data[0].rank;
        flexLP.innerHTML += data[0].leaguePoints;
    }
}
function getRankStelko(data){
    if(data[0].leagueId === "7a39c5ec-2cf0-3d5a-94f5-ba378c7e9f52"){
        soloRankS.innerHTML += data[0].tier + " " + data[0].rank;
        soloLPS.innerHTML += data[0].leaguePoints;
        flexRankS.innerHTML += data[1].tier + " " + data[1].rank;
        flexLP.innerHTML += data[1].leaguePoints;
    }
    else{
        soloRankS.innerHTML += data[1].tier + " " + data[1].rank;
        soloLPS.innerHTML += data[1].leaguePoints;
        flexRankS.innerHTML += data[0].tier + " " + data[0].rank;
        flexLPS.innerHTML += data[0].leaguePoints;
    }
}